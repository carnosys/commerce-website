from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from django.db import IntegrityError
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from django import forms
from .models import *

class CreateListing(forms.Form):
    title = forms.CharField(label="Enter title of your listing", max_length=100,required=True)
    description = forms.CharField(label="Enter the description of your listing", widget=forms.Textarea, max_length=500, required=True)
    starting_bid = forms.IntegerField(label="Enter the amount of starting widget", min_value=0, required=True)
    item_image_url = forms.URLField(label="Enter the url for image", required=False)
    category = forms.ChoiceField(label="Enter a caterogy",  choices=ListingCategory.choices)

 
class BidForm(forms.Form):
    bid_amount = forms.IntegerField(label="Enter the amount of bid", min_value=0)

class CommentForm(forms.Form):
    comment = forms.CharField(label= "Enter your comment", widget=forms.Textarea, required= True)    

def index(request, list_category=None ):
    if not list_category:
     return render(request, "auctions/index.html",{
        'listings': AuctionListing.objects.all()}
        )
    
    if list_category not in ListingCategory.values:
        return HttpResponse("Invalid category selected!!")
    
    else:
         return render(request, "auctions/index.html",{
        'listings': AuctionListing.objects.filter(category=list_category)}
        )


def login_view(request):
    if request.method == "POST":

        # Attempt to sign user in
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)

        # Check if authentication successful
        if user is not None:
            login(request, user)
            return HttpResponseRedirect(reverse("index"))
        else:
            return render(request, "auctions/login.html", {
                "message": "Invalid username and/or password."
            })
    else:
        return render(request, "auctions/login.html")


def logout_view(request):
    logout(request)
    return HttpResponseRedirect(reverse("index"))


def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]

        # Ensure password matches confirmation
        password = request.POST["password"]
        confirmation = request.POST["confirmation"]
        if password != confirmation:
            return render(request, "auctions/register.html", {
                "message": "Passwords must match."
            })

        # Attempt to create new user
        try:
            user = User.objects.create_user(username, email, password)
            user.save()
        except IntegrityError:
            return render(request, "auctions/register.html", {
                "message": "Username already taken."
            })
        login(request, user)
        return HttpResponseRedirect(reverse("index"))
    else:
        return render(request, "auctions/register.html")


def view_by_category(request):
    return render(request, "auctions/view_category.html")

@login_required
def create_listing_view(request):

    if request.method == "POST":
        form = CreateListing(request.POST)
        if form.is_valid():
            title = form.cleaned_data['title']
            description = form.cleaned_data['description']
            starting_bid= form.cleaned_data['starting_bid']
            url = form.cleaned_data['item_image_url']
            category = form.cleaned_data['category']

            listing = AuctionListing(title=title, description=description, starting_bid=starting_bid, item_image_url = url, category=category, assoc_user = request.user)
            listing.save()
            return redirect('create listing')
        
    else:
        return render(request,'auctions/createlisting.html',
                      {
            'form' : CreateListing(), 
        })    

    return render(request, 'auctions/createlisting.html', {
        'form' : CreateListing()
    })

@login_required
def display_watchlist(request):
    user = request.user
    return render(request,"auctions/watch_list.html", {
        "listing_items" : user.watchlist.all() 
    })


def active_listing_page(request):
    listings = AuctionListing.objects.all()
    return render(request, 'auctions/index.html', {
        'Listings': listings
    }
    )

def listing_page(request, id):
    listing = AuctionListing.objects.get(pk = id)
    bids = listing.bidoffers.all()
    comments = Comment.objects.filter(post=listing)
    if listing in request.user.watchlist.all():
        is_watchlisted = True
    else:
        is_watchlisted = False
    return render(request, "auctions/listing_page.html", {
        "listing": listing,
        "bidform": BidForm(),
        "bids": bids,
        "comments":comments,
        "commentform": CommentForm(),
        "is_watchlisted": is_watchlisted
    })


@login_required
def place_bid(request, id, user_id ):
    listing = AuctionListing.objects.get(pk=id)
    bids= listing.bidoffers.all()
    bid_form_data = BidForm(request.POST)
    if bid_form_data.is_valid():
        bid_amount = bid_form_data.cleaned_data['bid_amount']
        if not bids.exists():
            min_bid = listing.starting_bid
        else:
            min_bid = max(bid.bid_amount for bid in bids)

        if all(bid_amount> bid.bid_amount for bid in bids):
            user = User.objects.get(pk=user_id)
            bid = Bid(bid_amount = bid_amount, listing = listing, bidder = user )
            bid.save()
            return redirect('listing page', id=listing.id)
        else:
            return render(request, "auctions/listing_page.html", {
               "listing": listing,
               "form": BidForm(),
               "error":True,
               "min_bid": min_bid
             }
            )      


@login_required
def close_listing(request, id, user_id):
        listing = AuctionListing.objects.get(id=id)
        if listing.assoc_user.id == user_id:
          listing.status = 'Closed'
          bid_winner = listing.bidoffers.order_by('-bid_amount').first()
          if bid_winner:
              listing.winner = bid_winner.bidder
              listing.closing_bid = bid_winner.bid_amount
              listing.save() 
              return redirect('index')
          return HttpResponse('No one placed bid on your listing')
              
              
        else:
          return redirect('listing page', id = id )

@login_required
def add_comment(request, listing_id, commenter_id):
    if request.method=='POST':
        raw_comment = CommentForm(request.POST)
        if raw_comment.is_valid():

          cleaned_comment = raw_comment.cleaned_data['comment']
          if cleaned_comment:
            user = User.objects.get(pk=commenter_id)
            post = AuctionListing.objects.get(pk=listing_id)
            comment = Comment(commenter = user, post=post, comment=cleaned_comment)
            comment.save()
            return redirect('listing page', id=listing_id)
          else:
            return HttpResponse("Invalid comment")  
    else:
         return HttpResponse("Invalid method") 
    

  

@login_required
@require_POST
def add_to_watchlist(request, listing_id):
    listing = get_object_or_404(AuctionListing, pk=listing_id)
    request.user.watchlist.add(listing)
    return redirect("listing page", id=listing_id)


@login_required
@require_POST
def remove_from_watchlist(request, listing_id):
    listing = get_object_or_404(AuctionListing, pk=listing_id)
    request.user.watchlist.remove(listing)
    return redirect("listing page", id=listing_id)

