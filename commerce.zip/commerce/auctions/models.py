from django.contrib.auth.models import AbstractUser
from django.db import models
from django.core import validators

class ListingCategory(models.TextChoices):
    Fashion = "Fashion","fashion"
    Toys = "Toys", 'toys'
    Electronics = "Electronics", "electronics"
    Home = "Home","home"

class BidStatusChoices(models.TextChoices):
    Closed = "Closed","closed"
    Active = "Active","active"

class User(AbstractUser):
    watchlist = models.ManyToManyField('AuctionListing', blank=True, related_name="WatchListed_by")


class AuctionListing(models.Model):
    status = models.CharField(choices=BidStatusChoices.choices, default=BidStatusChoices.Active)
    title = models.CharField(max_length=100, null=False, unique=True)
    description = models.CharField(max_length=500, null=False)
    starting_bid = models.IntegerField(validators=[validators.MinValueValidator(0)], null=False)
    item_image_url = models.URLField(null=True)
    category = models.CharField(choices=ListingCategory.choices)
    assoc_user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="auction_listing") 
    winner = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    closing_bid = models.IntegerField(null=True)

    def __str__(self):
        return f"Title: {self.title}\nDescription:{self.description}\Starting bid: { self.starting_bid }\nCategory:{ self.category }\nPosted by:{ self.assoc_user}"


class Bid(models.Model):
    bid_amount = models.IntegerField(validators=[validators.MinValueValidator(0)], null=False)
    bidder = models.ForeignKey(User, on_delete=models.CASCADE, null=False, related_name="biddings")
    listing = models.ForeignKey(AuctionListing, on_delete=models.CASCADE, null=False, related_name="bidoffers")

    def __str__(self):
        return f'{self.bidder.username} placed bid of {self.bid_amount} on {self.listing.title}'

class Comment(models.Model):
    commenter = models.ForeignKey(User, on_delete=models.CASCADE, null=False, blank=False, related_name="comments")
    comment = models.TextField(blank=False, null=False)
    post = models.ForeignKey(AuctionListing,blank=False, null=False , on_delete=models.CASCADE, related_name="comments")