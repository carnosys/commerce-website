from django.urls import path

from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("login", views.login_view, name="login"),
    path("logout", views.logout_view, name="logout"),
    path("register", views.register, name="register"),
    path("categories", views.view_by_category, name="categories"),
    path("create-listing", views.create_listing_view, name="create listing"),
    path('watchlist',views.display_watchlist, name="watchlist"),
    path("listing-page/<int:id>", views.listing_page, name="listing page"),
    path("listing-page/place-bid/<int:id>/<int:user_id>", views.place_bid, name="place bid"),
    path("listing-page/close-listing/<int:id>/<int:user_id>", views.close_listing, name="close listing"),
    path("listing-page/add-comment/<int:listing_id>/<int:commenter_id>", views.add_comment, name="add comment" ),
    path("listing/<int:listing_id>/watch/add/",views.add_to_watchlist, name='add to watchlist'),
    path( "listing/<int:listing_id>/watch/remove/",views.remove_from_watchlist, name='remove from watchlist'),
    path('<str:list_category>', views.index, name="category index"),
    
]
