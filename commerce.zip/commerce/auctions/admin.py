from django.contrib import admin
from .views import AuctionListing, Comment, Bid


# Register your models here.

admin.site.register(AuctionListing)
admin.site.register(Bid)
admin.site.register(Comment)